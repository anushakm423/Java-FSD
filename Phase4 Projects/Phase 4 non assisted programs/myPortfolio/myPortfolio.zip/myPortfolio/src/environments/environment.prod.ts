export const environment = {
  production: true,
  baseUrl : `${window.location.protocol}//${window.location.hostname}/portfolio/`,
};
